let int = 27
let double = 0.3
// int * double // コンパイルエラー
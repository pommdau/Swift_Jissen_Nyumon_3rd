let a: Int = 123 // OK
// let b: Int = "abc" // コンパイルエラー
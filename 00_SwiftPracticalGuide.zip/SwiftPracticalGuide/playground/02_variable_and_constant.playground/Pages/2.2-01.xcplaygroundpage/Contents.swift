var a: Int // Int型の変数
let b: Int // Int型の定数
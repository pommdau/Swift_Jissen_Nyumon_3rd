let a: Int
// let b = a + 1 // aが初期化されていないためコンパイルエラー
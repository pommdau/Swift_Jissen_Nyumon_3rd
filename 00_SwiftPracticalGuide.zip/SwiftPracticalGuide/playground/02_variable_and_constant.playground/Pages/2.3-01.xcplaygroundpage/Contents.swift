func someFunction() {
    let a = "a"
    print(a) // OK
}

// print(a) // コンパイルエラー

someFunction()
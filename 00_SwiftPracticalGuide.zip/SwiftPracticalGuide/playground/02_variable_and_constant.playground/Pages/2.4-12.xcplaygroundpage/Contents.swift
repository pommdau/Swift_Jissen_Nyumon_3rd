let a = 7 // 7
-a // -7
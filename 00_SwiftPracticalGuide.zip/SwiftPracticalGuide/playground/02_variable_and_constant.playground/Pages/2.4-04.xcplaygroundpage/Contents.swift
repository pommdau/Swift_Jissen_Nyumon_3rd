let a: Int64 = 1
type(of: a) // Int64.Type
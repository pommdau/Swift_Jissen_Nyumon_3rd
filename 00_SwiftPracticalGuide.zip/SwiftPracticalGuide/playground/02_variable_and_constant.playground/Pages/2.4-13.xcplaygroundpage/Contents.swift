let a = false
!a // true

let b = true
!b // false
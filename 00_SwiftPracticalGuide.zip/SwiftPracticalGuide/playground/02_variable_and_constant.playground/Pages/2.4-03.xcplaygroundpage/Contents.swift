let a = 123
type(of: a) // Int.Type

let b = "abc"
type(of: b) // String.Type
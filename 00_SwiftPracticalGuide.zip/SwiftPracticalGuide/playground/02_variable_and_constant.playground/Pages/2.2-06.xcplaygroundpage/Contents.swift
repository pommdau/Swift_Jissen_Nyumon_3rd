let a = 123 // Int型の定数
let b = "abc" // String型の定数
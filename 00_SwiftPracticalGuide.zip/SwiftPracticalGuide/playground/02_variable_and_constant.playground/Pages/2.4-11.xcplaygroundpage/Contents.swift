let int = 27
let double = 0.3
Double(int) * double // 8.1
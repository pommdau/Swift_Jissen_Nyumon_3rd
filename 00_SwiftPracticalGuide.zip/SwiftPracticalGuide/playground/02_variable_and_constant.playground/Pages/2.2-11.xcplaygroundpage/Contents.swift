let a = 123
type(of: a) // Int.Type
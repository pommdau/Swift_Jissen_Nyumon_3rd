let a = 1
let b = a // 1
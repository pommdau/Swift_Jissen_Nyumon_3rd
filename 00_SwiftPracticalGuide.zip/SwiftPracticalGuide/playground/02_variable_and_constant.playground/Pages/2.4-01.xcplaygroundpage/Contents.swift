let a = 1 // 1
let b = a + 1 // 2
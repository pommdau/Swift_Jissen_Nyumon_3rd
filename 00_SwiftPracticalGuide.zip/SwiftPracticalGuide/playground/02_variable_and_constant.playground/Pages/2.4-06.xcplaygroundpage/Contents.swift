let a = "Hello, World!"
a.count // 13
a.starts(with: "Hello") // true
class SuperClass {
    let one = 1
}

// class BaseClass : SuperClass {
//     let two: Int
// 
//     override init() {
//         // twoの初期化前にスーパークラスを
//         // 初期化しようとしているためコンパイルエラー
//         super.init()
//         two = one + 1
//     }
// }
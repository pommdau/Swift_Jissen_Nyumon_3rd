class Sample {
    var value: String!
}

let sample = Sample()
// sample.value.isEmpty // 実行時エラー
class SuperClass {
    let one = 1
}

// class BaseClass : SuperClass {
//     let two: Int
// 
//     override init() {
//         // 初期化される前のoneにアクセスしているためコンパイルエラー
//         two = one + 1
//         super.init()
//     }
// }
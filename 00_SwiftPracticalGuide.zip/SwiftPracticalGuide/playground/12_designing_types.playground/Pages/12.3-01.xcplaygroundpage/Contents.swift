struct User {
    let id: Int
    let name: String
    let mailAddress: String?
}
var array1 = [1,2,3]
var array2 = array1
array1.append(4)
array1 // [1, 2, 3, 4]
array2 // [1, 2, 3]
func isEqual() -> Bool {
    return 1 == 1
}

func isEqual(_ x: Int, _ y: Int) -> Bool {
    return x == y
}

isEqual() // true
isEqual(1, 1) // true
func isEqual(_ x: Float, _ y: Float) -> Bool {
    return x == y
}

isEqual(1.1, 1.1) // true
func identity<T>(_ x: T) -> T {
    return x
}

identity(1) // 1
identity("abc") // "abc"
/// メソッドの説明です。
/// **太字**や[リンク](https://example.com/)が使用できます。
/// - parameter arg1: 第1引数の説明です。
/// - parameter arg2: 第2引数の説明です。
/// - returns: 戻り値の説明です。
/// - throws: エラーの説明です。
func someMethod(arg1: String, arg2: String) {}
let a = 1 + 1 // 2
let b = "a" + "b" // "ab"
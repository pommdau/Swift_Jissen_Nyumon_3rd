print("Hello.")

let x = "abc"
let y = "def"
let z = max(x, y) // "def"
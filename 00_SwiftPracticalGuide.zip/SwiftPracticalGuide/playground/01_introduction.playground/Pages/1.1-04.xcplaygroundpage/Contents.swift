let x = 123
let y = 456
let z = max(x, y) // 456
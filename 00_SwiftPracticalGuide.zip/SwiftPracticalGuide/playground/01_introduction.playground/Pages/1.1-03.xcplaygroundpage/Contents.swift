let a = 123 // aはInt型
let b = "abc" // bはString型
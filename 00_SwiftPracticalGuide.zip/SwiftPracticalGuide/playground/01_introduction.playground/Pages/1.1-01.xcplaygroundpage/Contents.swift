var a: Int // 変数はInt型

a = 456 // Int型の代入はOK
// a = "abc" // String型の代入はコンパイルエラー
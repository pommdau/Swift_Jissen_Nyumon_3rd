import Foundation

class SomeClass : NSObject {
    @objc func someMethod() {}
}

let selector = #selector(SomeClass.someMethod)
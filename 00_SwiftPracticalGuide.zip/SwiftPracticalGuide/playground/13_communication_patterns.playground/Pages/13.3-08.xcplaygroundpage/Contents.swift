typealias CompletionHandler = (Int?, Error?, Array<String>?) -> Void

func someMethod(completion: CompletionHandler) {}
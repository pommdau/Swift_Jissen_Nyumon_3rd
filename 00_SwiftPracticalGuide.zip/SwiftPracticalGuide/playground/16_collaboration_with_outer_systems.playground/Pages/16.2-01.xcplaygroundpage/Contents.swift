import Foundation

let encoder = JSONEncoder()
let decoder = JSONDecoder()
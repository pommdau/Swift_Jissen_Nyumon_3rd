// 構造体
struct SomeStruct {}

// クラス
class SomeClass {}

// 列挙型
enum SomeEnum {}
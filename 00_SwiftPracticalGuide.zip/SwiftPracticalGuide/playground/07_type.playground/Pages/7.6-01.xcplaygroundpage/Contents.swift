let array = [1, 2, 3]
let firstElement = array[0] // 1

let dictionary = ["a": 1, "b": 2, "c": 3]
let elementForA = dictionary["a"] // 1
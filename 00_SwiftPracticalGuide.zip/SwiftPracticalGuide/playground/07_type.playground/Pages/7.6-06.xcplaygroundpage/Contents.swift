let array = [1, 2, 3, 4]
let element = array[0] // Element
let slice = array[0...2] // ArraySlice<Element>
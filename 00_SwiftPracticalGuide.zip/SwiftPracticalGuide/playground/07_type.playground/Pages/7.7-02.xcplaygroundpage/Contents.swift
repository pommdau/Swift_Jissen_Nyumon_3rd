extension String {
    func printSelf() {
        print(self)
    }
}

let string = "abc"
string.printSelf()

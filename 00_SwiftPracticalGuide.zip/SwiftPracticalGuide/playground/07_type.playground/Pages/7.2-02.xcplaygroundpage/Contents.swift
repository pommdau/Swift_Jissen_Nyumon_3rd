struct SomeStruct {}

class SomeClass {}

let someStruct = SomeStruct()
let someClass = SomeClass()
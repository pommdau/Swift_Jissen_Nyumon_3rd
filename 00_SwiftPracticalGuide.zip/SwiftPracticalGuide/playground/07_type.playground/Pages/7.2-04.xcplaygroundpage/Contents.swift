struct SomeStruct {
    let value = 123

    func printValue() {
        print(value)
    }
}
struct SomeStruct {
    let value: Int

    init(value: Int) {
        // self.valueはプロパティの値を指し、valueは引数の値を指す
        self.value = value
    }
}
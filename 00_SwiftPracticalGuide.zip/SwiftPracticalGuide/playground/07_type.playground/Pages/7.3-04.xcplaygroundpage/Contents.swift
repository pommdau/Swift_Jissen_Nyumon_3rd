struct Greeting {
    // 値を持っていないためコンパイルエラー
//     static let signature: String
}
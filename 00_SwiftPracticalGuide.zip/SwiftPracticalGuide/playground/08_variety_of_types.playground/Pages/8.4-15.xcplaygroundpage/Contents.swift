// class User {
//     let id: Int
//     let name: String
//     // id, nameを初期化する方法が存在しないためコンパイルエラー
// }
class User {
    let id = 0
    let name = "Taro"

    // 以下と同等のイニシャライザが自動的に定義される
    // init() {}
}

let user = User()
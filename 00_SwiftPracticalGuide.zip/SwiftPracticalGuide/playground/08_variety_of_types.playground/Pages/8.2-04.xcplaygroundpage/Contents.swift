var mutableArray = [1, 2, 3]
mutableArray.append(4) // [1, 2, 3, 4]

let immutableArray = [1, 2, 3]
// immutableArray.append(4) // 再代入できないためコンパイルエラー
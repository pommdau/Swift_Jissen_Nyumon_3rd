enum Symbol : Character {
    case sharp = "#"
    case dollar = "$"
    case percent = "%"
}
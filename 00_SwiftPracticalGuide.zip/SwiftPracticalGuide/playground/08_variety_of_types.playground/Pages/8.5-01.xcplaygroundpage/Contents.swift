enum Weekday {
    case sunday
    case monday
    case tuesday
    case wednesday
    case thursday
    case friday
    case saturday
}

let sunday = Weekday.sunday // sunday
let monday = Weekday.monday // monday
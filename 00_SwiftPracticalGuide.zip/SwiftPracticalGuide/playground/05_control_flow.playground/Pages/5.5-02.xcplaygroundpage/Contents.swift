let value = 3

switch value {
case let matchedValue:
    print(matchedValue)
}

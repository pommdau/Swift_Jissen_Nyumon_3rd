let value = 2

if value <= 3 {
    print("valueは3以下です")
}

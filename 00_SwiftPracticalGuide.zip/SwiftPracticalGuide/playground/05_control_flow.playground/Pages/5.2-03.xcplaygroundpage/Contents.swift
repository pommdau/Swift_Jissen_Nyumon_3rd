let value = 1

// if value { // コンパイルエラー
// }
let value = 1

if value > 0 {
    print("valueは0より大きい値です")
}

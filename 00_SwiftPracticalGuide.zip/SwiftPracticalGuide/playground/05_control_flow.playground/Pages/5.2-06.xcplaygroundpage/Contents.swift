let optionalA = Optional(1)

if let a = optionalA {
    print("値は\(a)です")
} else {
    print("値が存在しません")
}

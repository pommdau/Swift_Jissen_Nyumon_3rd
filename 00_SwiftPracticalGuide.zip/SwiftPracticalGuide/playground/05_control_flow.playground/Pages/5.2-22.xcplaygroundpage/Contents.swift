let a = 1

switch a {
case 1:
    print("実行される")
    break
    print("実行されない")
default:
    break
}

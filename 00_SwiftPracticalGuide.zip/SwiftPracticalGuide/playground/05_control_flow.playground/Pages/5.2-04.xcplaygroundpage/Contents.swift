let value = 4

if value <= 3 {
    print("valueは3以下です")
} else {
    print("valueは3より大きいです")
}

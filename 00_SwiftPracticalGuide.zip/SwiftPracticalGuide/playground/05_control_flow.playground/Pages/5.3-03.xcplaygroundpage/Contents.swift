var a = 1

while a < 4 {
    print(a)
    a += 1
}

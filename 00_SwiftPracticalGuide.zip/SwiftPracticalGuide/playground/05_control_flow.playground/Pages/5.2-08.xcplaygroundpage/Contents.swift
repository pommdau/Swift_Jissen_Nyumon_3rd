let a: Any = 1

if let int = a as? Int {
    print("値はInt型の\(int)です")
}

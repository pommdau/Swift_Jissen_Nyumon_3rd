let array = [1, 2, 3, 4]

for case 2...3 in array {
    print("2以上3以下の値です")
}

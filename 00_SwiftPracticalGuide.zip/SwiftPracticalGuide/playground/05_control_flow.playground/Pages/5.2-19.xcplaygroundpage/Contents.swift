let a = true

switch a {
case true:
    print("true")
case false:
    print("false")
}

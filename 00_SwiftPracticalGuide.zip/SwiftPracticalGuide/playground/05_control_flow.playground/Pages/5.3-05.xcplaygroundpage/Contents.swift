var a = 1

repeat {
    print(a)
    a += 1
} while a < 1

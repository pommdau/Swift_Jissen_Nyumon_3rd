let array = [1, 2, 3]

for element in array {
    print(element)
}

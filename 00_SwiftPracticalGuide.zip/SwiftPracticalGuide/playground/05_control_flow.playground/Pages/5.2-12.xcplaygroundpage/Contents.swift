func printIfPositive(_ a: Int) {
//     guard a > 0 else {
//         // else節でprintIfPositive(_:)関数から退出していないため
//         // コンパイルエラー
//     }

    print(a)
}

printIfPositive(1)
var a = 1

while a < 1 {
    print(a)
    a += 1
}
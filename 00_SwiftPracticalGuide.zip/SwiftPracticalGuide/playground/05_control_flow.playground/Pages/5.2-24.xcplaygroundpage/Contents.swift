let a = 1

switch a {
case 1:
    print("case 1")
    fallthrough
case 2:
    print("case 2")
default:
    print("default")
}

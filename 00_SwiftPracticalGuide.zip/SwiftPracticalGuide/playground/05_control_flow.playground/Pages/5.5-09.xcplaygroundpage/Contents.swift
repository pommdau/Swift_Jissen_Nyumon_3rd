let value = 9

if case 1...10 = value {
    print("1以上10以下の値です")
}

func greet(user: String) {
    print("Hello, \(user)!")
}

greet(user: "Nishiyama")

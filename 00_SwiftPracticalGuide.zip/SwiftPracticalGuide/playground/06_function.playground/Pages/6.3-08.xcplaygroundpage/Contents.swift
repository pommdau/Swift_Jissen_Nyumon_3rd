let isEqual: (Int, Int) -> Bool = {
    return $0 == $1
}

isEqual(1, 1) // true
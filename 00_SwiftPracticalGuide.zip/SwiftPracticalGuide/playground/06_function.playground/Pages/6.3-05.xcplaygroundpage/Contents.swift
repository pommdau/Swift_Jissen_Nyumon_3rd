let lengthOfString = { (string: String) -> Int in // (String) -> Int
    return string.count
}

lengthOfString("I contain 23 characters") // 23
// func convertToInt(from string: String) -> Int {
//     // Int(_:)はInt?型を返すためコンパイルエラー
//     return Int(string)
// }
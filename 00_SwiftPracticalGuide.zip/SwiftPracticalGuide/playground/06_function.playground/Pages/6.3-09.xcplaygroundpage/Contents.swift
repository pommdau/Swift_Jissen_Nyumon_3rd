// isEqualの型が決まらないためコンパイルエラー
// let isEqual = {
//     return $0 == $1
// }
let numbers = [10, 20, 30, 40]
let moreThanTwenty = numbers.filter { $0 > 20 }
moreThanTwenty // [30, 40]
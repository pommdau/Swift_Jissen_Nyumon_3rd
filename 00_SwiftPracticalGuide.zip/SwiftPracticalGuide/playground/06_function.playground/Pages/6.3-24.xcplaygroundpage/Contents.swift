let array1 = [1, 2, 3]
let doubledArray1 = array1.map { $0 * 2 }
doubledArray1 // [2, 4, 6]

let array2 = [4, 5, 6]
let doubledArray2 = array2.map { $0 * 2 }
doubledArray2 // [8, 10, 12]
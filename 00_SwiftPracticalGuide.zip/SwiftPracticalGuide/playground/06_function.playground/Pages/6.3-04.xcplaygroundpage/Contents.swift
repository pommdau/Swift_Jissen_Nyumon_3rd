// let closure = { string in
//     // クロージャの型が決定しないためコンパイルエラー
//     return string.count * 2
// }
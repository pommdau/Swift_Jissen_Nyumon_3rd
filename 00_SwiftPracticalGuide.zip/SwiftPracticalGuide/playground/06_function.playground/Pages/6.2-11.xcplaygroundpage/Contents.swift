func string(from: Int) -> String {
    return "\(int)"
}

let int = 1
let double = 1.0

let string1 = string(from: int) // "1"
// let string2 = string(from: double) // コンパイルエラー
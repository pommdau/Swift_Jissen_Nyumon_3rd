@discardableResult
func functionWithDiscardableResult() -> String {
    return "Discardable"
}

functionWithDiscardableResult() // "Discardable"
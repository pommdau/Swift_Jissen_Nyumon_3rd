func printInt(_ int: Int) {
    print(int)
}

printInt(1)

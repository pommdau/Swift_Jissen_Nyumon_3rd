func makeMessage(toUser user: String) -> String {
    "Hello, \(user)!"
}
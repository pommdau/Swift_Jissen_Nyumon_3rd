var board = Array(repeating: Array(repeating: 1, count: 3), count: 3)
board // [[1, 1, 1], [1, 1, 1], [1, 1, 1]]
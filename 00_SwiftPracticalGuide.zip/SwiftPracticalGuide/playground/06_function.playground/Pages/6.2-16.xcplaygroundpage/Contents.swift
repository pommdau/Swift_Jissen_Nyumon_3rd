func makeMessage(toUser user: String) -> String {
    print(user)
//     "Hello, \(user)!" // return文が必須となりコンパイルエラー
}
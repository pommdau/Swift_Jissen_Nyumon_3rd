func greet(user: String = "Anonymous") {
    print("Hello, \(user)!")
}

greet()

greet(user: "Ishikawa")

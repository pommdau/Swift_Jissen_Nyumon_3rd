func double(_ x: Int) -> Int {
    return x * 2
}

let function = double // (Int) -> Int型
func invite(user: String, to group: String) {
    print("\(user) is invited to \(group).")
}

invite(user: "Ishikawa", to: "Soccer Club")

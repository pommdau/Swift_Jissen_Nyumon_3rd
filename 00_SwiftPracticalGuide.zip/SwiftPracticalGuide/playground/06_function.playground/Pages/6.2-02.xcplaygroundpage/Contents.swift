func functionWithDiscardableResult() -> String {
    return "Discardable"
}

_ = functionWithDiscardableResult() // "Discardable"
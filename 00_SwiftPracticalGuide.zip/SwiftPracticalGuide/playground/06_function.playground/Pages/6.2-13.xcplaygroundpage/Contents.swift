func greet(user: String) -> Void {
    print("Hello, \(user)!")
}

greet(user: "Nishiyama")

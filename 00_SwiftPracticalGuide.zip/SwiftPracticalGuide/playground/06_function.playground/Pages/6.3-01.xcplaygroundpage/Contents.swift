let double = { (x: Int) -> Int in
    return x * 2
}

double(2) // 4
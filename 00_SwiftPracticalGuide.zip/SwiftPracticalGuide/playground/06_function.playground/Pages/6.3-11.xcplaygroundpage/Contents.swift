// 戻り値がないクロージャ
let emptyReturnValueClosure: () -> Void = {}

// 1つの戻り値を持つクロージャ
let singleReturnValueClosure: () -> Int = {
    return 1
}
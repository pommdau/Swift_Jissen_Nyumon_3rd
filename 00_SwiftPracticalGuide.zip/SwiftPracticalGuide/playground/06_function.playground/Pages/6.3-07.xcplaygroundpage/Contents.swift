// クロージャの引数にデフォルト引数を指定しているためコンパイルエラー
// let greet = { (user: String = "Anonymous") -> Void in
//     print("Hello, \(user)!")
// }
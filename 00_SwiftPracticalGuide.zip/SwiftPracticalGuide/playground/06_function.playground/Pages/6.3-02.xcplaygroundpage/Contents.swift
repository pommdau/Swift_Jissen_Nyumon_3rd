let closure: (Int) -> Int
func someFunction(x: (Int) -> Int) {}
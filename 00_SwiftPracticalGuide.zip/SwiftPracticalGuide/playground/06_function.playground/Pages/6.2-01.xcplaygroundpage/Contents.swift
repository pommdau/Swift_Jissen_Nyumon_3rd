func double(_ x: Int) -> Int {
    return x * 2
}

double(2) // 4
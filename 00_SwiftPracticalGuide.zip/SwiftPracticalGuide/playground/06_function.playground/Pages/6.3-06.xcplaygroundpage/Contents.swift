let add = { (x: Int, y: Int) -> Int in
    return x + y
}

add(1, 2) // 3
import Dispatch

// グローバルキューを取得
let queue = DispatchQueue.global(qos: .userInitiated)
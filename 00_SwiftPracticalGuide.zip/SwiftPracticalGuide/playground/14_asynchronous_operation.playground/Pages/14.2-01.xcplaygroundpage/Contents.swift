import Dispatch

let queue = DispatchQueue.main // メインディスパッチキューを取得
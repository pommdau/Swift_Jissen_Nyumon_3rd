protocol SomeProtocol {}

class SomeSuperClass {}

class SomeClass : SomeSuperClass, SomeProtocol {}
protocol SomeProtocol {
    var someProperty: Int { get set }
}
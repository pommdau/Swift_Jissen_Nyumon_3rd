do {
    defer {
        print("second")
    }
    print("first")
}

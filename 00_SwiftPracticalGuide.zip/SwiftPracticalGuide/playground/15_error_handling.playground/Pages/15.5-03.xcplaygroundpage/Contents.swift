// func title(forButtonAt index: Int) -> String {
//     // ケースがInt型の値を網羅できていないためコンパイルエラー
//     switch index {
//     case 0:
//         return "赤"
//     case 1:
//         return "青"
//     case 2:
//         return "黄"
//     }
// }
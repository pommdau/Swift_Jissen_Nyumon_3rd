func randomInt() -> Int {
    fatalError("まだ実装されていません")
}
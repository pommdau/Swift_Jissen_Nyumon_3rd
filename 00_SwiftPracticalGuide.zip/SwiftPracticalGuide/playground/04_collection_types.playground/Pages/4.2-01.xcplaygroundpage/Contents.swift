let a = [1, 2, 3]
let b = ["a", "b", "c"]
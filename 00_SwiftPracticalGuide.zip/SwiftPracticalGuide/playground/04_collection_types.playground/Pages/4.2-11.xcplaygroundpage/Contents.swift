var integers = [1, 3, 4]
integers.insert(2, at: 1) // [1, 2, 3, 4]
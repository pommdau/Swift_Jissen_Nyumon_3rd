let strings = ["abc", "def", "ghi"] // インデックスは0、1、2
let strings1 = strings[0] // "abc"
let strings2 = strings[1] // "def"
let strings3 = strings[2] // "ghi"
// let strings4 = strings[3] // 3は範囲外なので実行時エラー
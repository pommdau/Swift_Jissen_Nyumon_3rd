let integerRange = 1..<3 // CountableRange<Int>型
let doubleRange = 1.0..<3.0 // Range<Double>型
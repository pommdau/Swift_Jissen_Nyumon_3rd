let range = 1..<4 // CountableRange(1..<4)

for value in range {
    print(value)
}

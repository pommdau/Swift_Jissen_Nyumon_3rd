// [String: [Int]]型
let array = ["even": [2, 4, 6, 8], "odd": [1, 3, 5, 7, 9]]
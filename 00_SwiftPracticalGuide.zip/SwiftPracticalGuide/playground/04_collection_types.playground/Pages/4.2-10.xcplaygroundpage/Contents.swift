var integers = [1, 2, 3]
integers.append(4) // [1, 2, 3, 4]
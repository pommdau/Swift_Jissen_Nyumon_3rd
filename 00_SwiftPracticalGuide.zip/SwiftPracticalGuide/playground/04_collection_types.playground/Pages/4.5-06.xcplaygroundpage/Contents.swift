let string = "abc"

// 文字数のカウント
string.count // 3

// 要素の列挙
for character in string {
    print(character)
}

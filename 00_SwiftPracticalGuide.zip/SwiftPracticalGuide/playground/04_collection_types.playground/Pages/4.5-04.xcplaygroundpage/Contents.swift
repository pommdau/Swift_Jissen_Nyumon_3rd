let string = "abc"
// let character = string[string.endIndex] // 実行時エラー
let range = 1...4 // CountableClosedRange(1...4)
range.contains(2) // true
range.contains(5) // false
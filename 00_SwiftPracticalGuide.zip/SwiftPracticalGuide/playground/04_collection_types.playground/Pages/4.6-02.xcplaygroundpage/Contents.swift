let array = [1, 2, 3, 4, 5, 6]
let filtered = array.filter({ element in element % 2 == 0 })
filtered // [2, 4, 6]
let string = "a" // String型
let character: Character = "a" // Character型
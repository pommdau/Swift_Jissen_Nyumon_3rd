let string = "abc" // String型
let startIndex = string.startIndex // String.Index型
let endIndex = string.endIndex // String.Index型
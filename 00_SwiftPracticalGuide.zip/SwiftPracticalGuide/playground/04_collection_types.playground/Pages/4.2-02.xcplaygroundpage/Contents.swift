let strings = ["a", "b", "c"] // [String]型
let numbers = [1, 2, 3] // [Int]型
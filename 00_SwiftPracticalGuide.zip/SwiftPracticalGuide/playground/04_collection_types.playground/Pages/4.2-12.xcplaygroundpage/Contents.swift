let integers1 = [1, 2, 3] // [Int]型
let integers2 = [4, 5, 6] // [Int]型
let result = integers1 + integers2 // [1, 2, 3, 4, 5, 6]
let dictionary = ["key": 1] // [String : Int]型
let value = dictionary["key"] // 1（Optional<Int>型）
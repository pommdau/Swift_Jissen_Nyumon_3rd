let integers = [1, 2, 3] // [Int]型
let strings = ["a", "b", "c"] // [String]型
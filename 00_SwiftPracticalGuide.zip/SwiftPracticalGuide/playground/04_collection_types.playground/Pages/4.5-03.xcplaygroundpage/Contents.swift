let string = "abc" // "abc"（String型）
let character = string[string.startIndex] // "a"（Character型）
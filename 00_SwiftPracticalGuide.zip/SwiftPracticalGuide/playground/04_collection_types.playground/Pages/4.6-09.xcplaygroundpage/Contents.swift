let array = [1, 2, 3, 4, 5, 6]

array[3] // 4
array.isEmpty // false
array.count // 6
array.first // 1
array.last // 6
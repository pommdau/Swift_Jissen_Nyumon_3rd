let range1 = 1..<4 // OK
// let range2 = 1..<"a" // Int型とString型は別の型なのでコンパイルエラー
var strings = ["abc", "def", "ghi"]
strings[1] = "xyz"
strings // ["abc", "xyz", "ghi"]
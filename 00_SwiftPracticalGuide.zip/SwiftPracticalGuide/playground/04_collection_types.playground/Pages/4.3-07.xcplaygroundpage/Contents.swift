let dictionary = ["key1": "value1"]
let valueForKey1Exists = dictionary["key1"] != nil // true
let valueForKey2Exists = dictionary["key2"] != nil // false
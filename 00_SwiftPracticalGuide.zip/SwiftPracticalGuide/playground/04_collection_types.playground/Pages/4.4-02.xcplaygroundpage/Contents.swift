let range = 1...4 // CountableClosedRange(1...4)

for value in range {
    print(value)
}

var integers = [1, 2, 3, 4, 5]

integers.remove(at: 2)
integers // [1, 2, 4, 5]

integers.removeLast()
integers // [1, 2, 4]

integers.removeAll()
integers // []
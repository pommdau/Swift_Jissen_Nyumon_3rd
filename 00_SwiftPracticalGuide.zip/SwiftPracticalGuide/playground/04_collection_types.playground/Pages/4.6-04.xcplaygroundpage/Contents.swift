let array = [1, 2, 3, 4, 5, 6]
let converted = array.map({ element in String(element) })
converted // ["1", "2", "3", "4", "5", "6"]
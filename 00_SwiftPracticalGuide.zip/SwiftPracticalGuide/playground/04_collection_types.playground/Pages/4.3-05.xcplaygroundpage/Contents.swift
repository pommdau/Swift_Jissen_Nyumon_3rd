// let dictionary: [String: Int] = [
//     1: 2, // キーの型が異なるためコンパイルエラー
//     "key": "value" // 値の型が異なるためコンパイルエラー
// ]
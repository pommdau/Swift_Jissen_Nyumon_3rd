let tuple = (1, "a")
let int = tuple.0 // 1
let string = tuple.1 // "a"
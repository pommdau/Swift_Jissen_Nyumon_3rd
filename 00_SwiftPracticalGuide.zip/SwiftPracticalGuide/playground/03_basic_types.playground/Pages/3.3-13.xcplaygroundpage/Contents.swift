let a: Int = 123
let b: Float = 123.0
// a + b // コンパイルエラー
a + Int(b) // 246
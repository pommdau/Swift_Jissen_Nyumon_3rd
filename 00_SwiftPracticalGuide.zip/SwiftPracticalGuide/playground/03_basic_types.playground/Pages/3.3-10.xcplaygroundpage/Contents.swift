123 == 456 // false
123 != 456 // true
123 > 456 // false
123 >= 456 // false
123 < 456 // true
123 <= 456 // true
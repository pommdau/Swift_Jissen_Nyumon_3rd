let a = "1\n2\n3"
print(a)

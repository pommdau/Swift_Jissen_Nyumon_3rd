let a = true // true
let b = !a // false
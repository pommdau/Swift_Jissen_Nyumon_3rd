let a = false || false // false
let b = false || true // true
let c = true || false // true
let d = true || true // true
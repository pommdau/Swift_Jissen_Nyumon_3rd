let a = false && false // false
let b = false && true // false
let c = true && false // false
let d = true && true // true
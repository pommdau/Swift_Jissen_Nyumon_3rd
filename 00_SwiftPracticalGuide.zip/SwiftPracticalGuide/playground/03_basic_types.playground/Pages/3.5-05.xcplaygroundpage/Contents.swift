let optionalInt: Int? = nil
let optionalString: String? = nil

print(type(of: optionalInt), String(describing: optionalInt))
print(type(of: optionalString), String(describing: optionalString))

let optionalInt: Int? = 1
let int = optionalInt ?? 3 // 1
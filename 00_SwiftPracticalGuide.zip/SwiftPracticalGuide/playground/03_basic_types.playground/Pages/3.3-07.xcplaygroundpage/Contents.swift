let a: Int = 123
// let b: Int64 = a // コンパイルエラー

let c: Float = 1.0
// let d: Double = c // コンパイルエラー
let a: Int? = 1
let b: Int? = 1

a! + b! // 2
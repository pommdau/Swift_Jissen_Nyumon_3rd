let any = 1 as Any
let int = any as! Int
// let string = any as! String // 実行時エラー
let a = "abc"
let b = "def"
let c = a + b // "abcdef"
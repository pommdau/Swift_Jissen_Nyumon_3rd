let result = "優勝"
let output = "結果: \(result)" // 結果: 優勝
var a: String? = "a"
var b: String! = "b"

print(type(of: a))
print(type(of: b))

var c: String! = a
var d: String? = b

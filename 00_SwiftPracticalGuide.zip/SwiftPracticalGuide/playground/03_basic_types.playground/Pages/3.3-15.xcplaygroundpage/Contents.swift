import Foundation // Foundationを利用できるようにする

sin(Float.pi / 2.0) // 1
log(1.0) // 0
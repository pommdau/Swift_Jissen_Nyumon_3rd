let tuple = (int: 1, string: "a")
let int = tuple.int // 1
let string = tuple.string // "a"
let s1 = "123"
let i1 = Int(s1) // 123

let s2 = "abc"
let i2 = Int(s2) // nil
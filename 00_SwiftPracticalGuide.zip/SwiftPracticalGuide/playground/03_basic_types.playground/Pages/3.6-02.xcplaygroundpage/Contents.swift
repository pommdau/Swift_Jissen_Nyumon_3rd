let a: Any = 1
let b: Any = 2
// a + b // コンパイルエラー
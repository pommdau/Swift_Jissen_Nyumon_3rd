let result = 7 + 9
let output = "結果: \(result)" // 結果: 16
let a: Any = 1
let isInt = a is Int // true
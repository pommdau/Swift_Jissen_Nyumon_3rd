let optionalRange = Optional(0..<10)
let containsSeven = optionalRange?.contains(7)

print(String(describing: containsSeven))

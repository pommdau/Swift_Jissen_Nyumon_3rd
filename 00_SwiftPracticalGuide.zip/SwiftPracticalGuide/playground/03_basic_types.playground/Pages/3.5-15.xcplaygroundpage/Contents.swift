let optionalDouble = Optional(1.0) // Optional(1.0)
let optionalIsInfinite = optionalDouble?.isInfinite

print(String(describing: optionalIsInfinite))

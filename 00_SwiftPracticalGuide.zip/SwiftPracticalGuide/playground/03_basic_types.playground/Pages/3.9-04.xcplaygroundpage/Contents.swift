let intLeft = 12
let intRight = 13
intLeft < intRight // true

let floatLeft = 3.4 as Float
let floatRight = 3.9 as Float
floatLeft > floatRight // false

let doubleLeft = 3.4
let doubleRight = 3.9
doubleLeft > doubleRight // false

let stringLeft = "abc"
let stringRight = "def"
stringLeft <= stringRight // true
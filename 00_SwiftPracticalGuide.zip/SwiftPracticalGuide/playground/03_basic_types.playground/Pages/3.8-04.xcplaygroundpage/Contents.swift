let any = 1 as Any
let int = any as? Int // Optional(1)
let string = any as? String // nil
let optionalInt: Int? = nil
let int = optionalInt ?? 3 // 3
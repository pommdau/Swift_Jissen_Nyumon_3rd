let a: Int? = nil // OK
// let b = nil // 定数の型が決まらないためコンパイルエラー
let a: Int = 123
let b: Int64 = Int64(a) // OK

let c: Float = 1.0
let d: Double = Double(c) // OK
let string1 = "abc"
let string2 = "def"
string1 == string2 // false
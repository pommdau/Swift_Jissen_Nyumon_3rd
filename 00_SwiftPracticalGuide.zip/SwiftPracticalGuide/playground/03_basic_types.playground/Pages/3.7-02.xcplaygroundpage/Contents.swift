var tuple: (Int, String)
tuple = (1, "a")
let c: Float = 1.99
let d: Int = Int(c) // 1

let e: Double = 1.23456789
let f: Float = Float(e) // 1.234568
let a: Int! = 1
a + 1 // Int型と同様に演算が可能

var b: Int! = nil
// b + 1 // 値が入っていないため実行時エラー
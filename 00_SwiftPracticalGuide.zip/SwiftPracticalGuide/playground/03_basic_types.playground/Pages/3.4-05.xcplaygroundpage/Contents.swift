let haiku = """
五月雨を
あつめて早し
最上川
"""

print(haiku)

let optionalInt = Optional(1)
let optionalString = Optional("a")

print(type(of: optionalInt), String(describing: optionalInt))
print(type(of: optionalString), String(describing: optionalString))

let string: Any = "abc"
let int: Any = 123
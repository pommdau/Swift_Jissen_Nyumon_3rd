let a = true // Bool型
let b = false // Bool型
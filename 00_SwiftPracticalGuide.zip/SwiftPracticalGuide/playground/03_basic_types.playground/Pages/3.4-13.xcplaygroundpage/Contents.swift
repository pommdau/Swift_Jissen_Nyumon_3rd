var c: String = "abc"
let d: String = "def"
c.append(d) // "abcdef"

let e: String = "abc"
let f: String = "def"
e + f // "abcdef"
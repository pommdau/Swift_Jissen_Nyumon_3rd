let i = 123
let s = String(i) // "123"
let anyLeft = "abc" as Any
let anyRight = "def" as Any
// anyLeft == anyRight // コンパイルエラー
// anyLeft != anyRight // コンパイルエラー
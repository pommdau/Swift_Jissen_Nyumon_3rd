let a: Double = 0.0 / 0.0
a.isNaN // true

let b: Double = Double.nan
b.isNaN // true
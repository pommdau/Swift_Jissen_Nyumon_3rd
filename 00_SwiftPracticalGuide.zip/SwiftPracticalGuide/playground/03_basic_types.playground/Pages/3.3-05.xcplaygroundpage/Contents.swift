let a: Double = 1.0 / 0.0
a.isInfinite // true

let b: Double = Double.infinity
b.isInfinite // true
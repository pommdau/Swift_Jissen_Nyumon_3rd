let a: Float = 123
let b: Double = 123
// a == b // コンパイルエラー
a == Float(b) // true
let int: Int
let string: String
(int, string) = (1, "a")
int // 1
string // "a"
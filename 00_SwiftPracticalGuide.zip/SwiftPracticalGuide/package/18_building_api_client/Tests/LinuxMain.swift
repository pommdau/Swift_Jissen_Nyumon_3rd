import XCTest

import GitHubSearchTests

var tests = [XCTestCaseEntry]()
tests += GitHubSearchTests.allTests()
XCTMain(tests)

public struct User : Decodable {
    public var id: Int
    public var login: String
}

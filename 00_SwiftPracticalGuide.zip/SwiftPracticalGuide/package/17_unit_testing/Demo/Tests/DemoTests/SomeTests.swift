import XCTest

class SomeTests : XCTestCase {
    func testSomeThing() {
        XCTAssertEqual(1 + 1, 2)
    }
}

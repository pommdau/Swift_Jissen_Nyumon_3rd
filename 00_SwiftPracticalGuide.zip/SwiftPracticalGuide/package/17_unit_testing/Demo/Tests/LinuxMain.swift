import XCTest

import DemoTests

var tests = [XCTestCaseEntry]()
tests += DemoTests.allTests()
XCTMain(tests)

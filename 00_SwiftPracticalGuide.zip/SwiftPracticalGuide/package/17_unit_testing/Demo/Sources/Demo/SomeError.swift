struct SomeError : Error {
}

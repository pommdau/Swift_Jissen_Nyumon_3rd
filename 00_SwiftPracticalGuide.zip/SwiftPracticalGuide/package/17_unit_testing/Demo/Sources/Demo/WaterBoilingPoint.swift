extension Temperature {
    internal static var waterBoilingPoint: Temperature {
        return Temperature(celsius: 100)
    }
}

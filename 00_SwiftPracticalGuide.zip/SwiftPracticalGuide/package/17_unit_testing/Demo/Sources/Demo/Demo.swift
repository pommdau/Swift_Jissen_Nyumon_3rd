struct Demo {
    var text = "Hello, World!"
}
